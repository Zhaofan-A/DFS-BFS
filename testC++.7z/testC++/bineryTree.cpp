#include <stdio.h>
#include <iostream>
using namespace std;
int main()
{
    //freopen("1.txt","r",stdin);
    //freopen("2.txt","w",stdout);
    int T;
    scanf("%d",&T);
	printf("intput four int \n");
    while(T--){
        int n,m,p,q,x,y;
        scanf("%d%d%d%d",&n,&m,&p,&q);
        //节点数据不会大于1w，利用数组下标
        //a[][0]  存储父亲
        //a[][1]  a[][2]  分别存储左右孩子
        //这里初始值为0，说明为空
        int a[100000][3]={0};
        for(int i=0;i<m;i++){
            scanf("%d%d",&x,&y);
            //一个孩子也没有
            if(a[x][1]==0) a[x][1]=y;
            else a[x][2]=y;
            a[y][0]=x;
        }
        int judge[100000]={0};
        int ans=0;
        while(1){
            //p和q两个节点的深度不同，当其中一个退到根节点，就不用再操作了
            if(a[p][0]!=0){  //有父亲
                judge[a[p][0]]++;
                p=a[p][0];
            }
            if(a[q][0]!=0){  //有父亲
                judge[a[q][0]]++;
                q=a[q][0];
            }
            //printf("%d %d\n",p,q);
            if(judge[p]==2||judge[q]==2) {   //交叉
                if(judge[p]==2) printf("%d ",p),ans=p;
                else printf("%d ",q),ans=q;
                break;
            }else if(p==q){    //树根
                printf("%d ",p),ans=p;
                break;
            }
        }
        //队列
        int sum[10000]={0};
        int index=1;
        sum[1]=ans;
        int step=1;
        while(step<=index){
            if(a[sum[step]][1]!=0){
                sum[++index]=a[sum[step]][1];
            }
            if(a[sum[step]][2]!=0){
                sum[++index]=a[sum[step]][2];
            }
            step++;
        }
        printf(" %d\n",index);
    }
}