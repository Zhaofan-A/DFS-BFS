#include <iostream>
#include<string.h>
using namespace std;
struct MyStruct
{
	int x[2];
	int y[2];
	int cross_time;
};
MyStruct wormhole[5];
 
int start_x, start_y, end_x, end_y, final_time, N;
int visit[5], map[1000][1000];
void dfs(int now_x, int now_y, int time) {
	for (int i = 0; i < N + 1; i++)
	{
 
 
		if (time >= final_time && final_time != 0)	return;
 
		if (now_x == end_x && now_y == end_y)
		{
			if (time < final_time || final_time == 0)
			{
				final_time = time;
			}
			return;
		}//递归开关
		if (visit[i] == 1)
		{
			continue;
		}//虫洞重走剪枝
		if (i != N)
		{
			for (int j = 0; j < 2; j++)
			{
				int a_time;//到达虫洞所需时间
				a_time = abs(wormhole[i].x[j] - now_x) + abs(wormhole[i].y[j] - now_y);
				visit[i] = 1;
				dfs(wormhole[i].x[!j], wormhole[i].y[!j], time + a_time + wormhole[i].cross_time);
				visit[i] = 0;
			}
		}
 
		else
		{
			int direct_time = abs(end_x - now_x) + abs(end_y - now_y);//直接走的时间
			dfs(end_x, end_y, time + direct_time);
		}
 
 
 
	}
 
 
}
void init() {
	memset(wormhole, 0, sizeof(wormhole) * 5);
	memset(visit, 0, sizeof(visit));
	memset(map, -1, sizeof(map));
	final_time = 0;
}
int main()
{
	int T = 1;
	cout << "#" << !T<< endl;
	
	cin >> T;
	for (int i = 0; i < T; i++)
	{
		init();
		cin >> N;
		cin >> start_x >> start_y >> end_x >> end_y;
		for (int j = 0; j < N; j++)
		{
 
			cin >> wormhole[j].x[0] >> wormhole[j].y[0] >> wormhole[j].x[1] >> wormhole[j].y[1]
				>> wormhole[j].cross_time;
		}
		dfs(start_x, start_y, 0);
		cout << "#" << i + 1 << " " << final_time << endl;
	}
}
