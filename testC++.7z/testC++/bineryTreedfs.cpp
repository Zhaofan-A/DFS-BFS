#include <stdio.h>
#include <iostream>
#include<string.h>
using namespace std;


int n,m,p,q;
int num;

struct Node{
	int val;
	int root;
	int left;
	int right;
	Node(){}
	Node(int a,int b,int c,int d):val(a),root(b),left(c),right(d){}
};
Node nodes[1000];


Node dfs(Node rooot,Node p,Node q){
    if(rooot.val == 0  || rooot.val == p.val || rooot.val== q.val){
		cout<<"rooot.val =  "<<rooot.val<<endl;
		return rooot;
	}
	Node left = dfs(nodes[rooot.left],p,q);
	Node right = dfs(nodes[rooot.right],p,q);
	if(left.val == 0 ) return right;
	if(right.val == 0 ) return left;
	return rooot;
}

int  count(Node rooot){
    if(rooot.val == 0){
		return num;
	}
	num++;
    count(nodes[rooot.left]);
	count(nodes[rooot.right]);
	return num;
}

int main()
{
    int T;
    scanf("%d",&T);
	memset(nodes,0,sizeof(Node)*100);
    while(T--){
        int x,y;
        scanf("%d%d%d%d",&n,&m,&p,&q);
		cout<<"n =  "<<n<<" m =  "<<m <<" p=  "<<p<<" q =  "<<q <<endl;
		 for(int i=0;i<m;i++){
            //scanf("%d%d",&x,&y);
			cin >>x >>y;
            nodes[x].val =x;
			if(nodes[x].left == 0){
				nodes[x].left = y;
			}else{
				nodes[x].right = y;
			}
			if(nodes[y].val == 0){
				nodes[y].val = y;
			}
			nodes[y].root = x;
        }
	    Node node = dfs(nodes[1],nodes[p],nodes[q]);
		
		int cou = count(node,0);
     
        printf(" %d %d\n",node.val,cou);
    }
	return 0;
}