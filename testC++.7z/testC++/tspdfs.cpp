#include<stdio.h>
#include<iostream>
#include<string.h>
#include<queue>
using namespace std;
int T;
int N;
int visit[10]; //第几轮，有几个顾客没有访问过

struct Position
{
    int x,y;
	int distanced;
};

Position positions[10];

int start_x, start_y, end_x, end_y, final_distance;

void dfs(int now_x, int now_y, int nowdistance,int step){
	for(int i =0 ;i < N+1 ;i++){
		/*if(nowdistance >= final_distance && final_distance!=0){
			return;
		}*/
		if (now_x == end_x && now_y == end_y && step == N)
		{
			if (nowdistance < final_distance || final_distance == 0)
			{
				final_distance = nowdistance;
			}
			cout<<"nowDisatance  = "<< nowdistance<< endl;
			return;
		}
		if(visit[i]==1){
			continue;
		}
		
		if (i != N)
		{
			int distance;
			distance = abs(positions[i].x - now_x) + abs(positions[i].y - now_y);
			cout<<"distance  = "<< distance<< endl;
			step++;
			visit[step] = 1;
			dfs(positions[i].x, positions[i].y, nowdistance + distance,step);
			step--;
			visit[step] = 0;
		}else
		{
			int endistance = abs(end_x - now_x) + abs(end_y - now_y);
			dfs(end_x, end_y, nowdistance + endistance,step);
		}
	}
	
}

int main(){
    scanf("%d",&T);
	memset(visit,0,sizeof(visit));
    while(T--){
 
		cin>>start_x>>start_y>>end_x>>end_y;
		for(int i= 0; i<N;i++){
			cin>>positions[i].x>>positions[i].y;
		}
		cout<<"start_x  = "<< start_x<<" start_y  = "<< start_y<<" end_x  = "<< end_x<<" end_y  = "<< end_y<< endl;
        dfs(start_x,start_y,0,0);
        printf("%d\n",final_distance);
    }
    return 0;
}