#include<stdio.h>
#include<iostream>
#include<string.h>
#include<queue>
using namespace std;
int T;
int N;
int visit[12][12]; //第几轮，有几个顾客没有访问过

struct Position
{
    int x,y,distanced,cus;
};

Position positions[12];

int distance(Position po1,Position po2){
	int distance ;
	//两点之间距离
	int dx=(po1.x-po2.x)>0?(po1.x-po2.x):(po2.x-po1.x);
	int dy=(po1.y-po2.y)>0?(po1.y-po2.y):(po2.y-po1.y);
	distance=dx+dy;
	cout<<"dis : "<<distance<<endl;
    return distance;
}

int  bfs(int x,int y){
	 queue<Position> Q;
	 Position a,next;
	 a.x= x;
	 a.y= y;
	 a.distanced = 0;
	 a.cus = 0;
	 Q.push(a);
	 int allNdis= 0;
	 while(!Q.empty()){
		 a = Q.front();
		 Q.pop();
		 if(a.x == positions[1].x && a.y == positions[1].y && a.cus == (N+1)){
			 allNdis = a.distanced;
			 cout<<"a.cus : "<<a.cus<<endl;
			 break;
		 }
		 next = a;
		 for(int i= 2 ; i< N+2;i++){
			 next.x = positions[i].x;
			 next.y = positions[i].y;
			 if(x>0&&x<100 && y>0&&y<100 && visit[a.cus+1][i] != 1){
				  next.distanced =a.distanced + distance(a,positions[i]);
				  next.cus = a.cus+1;
				  visit[next.cus][i] = 1;
				  Q.push(next);
			 }
		 }
	 }
	 return allNdis;
}

int main(){
    scanf("%d",&T);
	memset(visit,0,sizeof(visit));
    while(T--){
        cin>>N;
		cin>>positions[0].x>>positions[0].y>>positions[1].x>>positions[1].y;
		for(int i= 0; i<N;i++){
			cin>>positions[i].x>>positions[i].y;
		}
        int distance = bfs(positions[0].x,positions[0].y);
        printf("%d\n",distance);
    }
    return 0;
}