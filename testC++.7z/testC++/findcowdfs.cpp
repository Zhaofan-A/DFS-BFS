#include <stdio.h>
#include<string.h>
#include <iostream>
using namespace std;

const int N = 100000;
int n,k;
int map[10000];
int minValue = 100000;

int check(int x){
  if(x<0 || x>=N || map[x])
        return 0;
    return 1;
}

void dfs(int x,int step){
   if(x == k){
	   cout<<"finded"<<step<<endl;
	   if(step < minValue){
		   minValue = step;
	   }
       return;   
   }
   if(step > minValue){
	    return;   
   }
   x = x +1;
   if(check(x)){
	   cout<<"+"<<step<<endl;
	   step = step+1;
	   map[x] =1;
	   dfs(x,step);
	   step = step-1;
	   map[x] =0;
	   x = x -1;
   }
   x = x - 1;
   if(check(x)){
	   cout<<"-"<<step<<endl;
	   step = step+1;
	   map[x] =1;
	   dfs(x,step);
	   step = step-1;
	   map[x] =0;
	   x = x +1;
   }
   x = x*2;
   if(check(x)){
	   cout<<"*"<<step<<endl;
	   step = step+1;
	   map[x] =1;
	   dfs(x,step);
	   step = step-1;
	   map[x] =0;
	   x = x/2;
   }
}

int main()
{
    cin>>n>>k;
    memset(map,0,sizeof(map));
	
    dfs(n,0);
    cout<<"resulte : "<<minValue<<endl;
	
    return 0;
}
